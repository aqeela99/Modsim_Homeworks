import tkinter

# initialize tk
root = tkinter.Tk()

# create canvas
myCanvas = tkinter.Canvas(root, bg="pink", height=400, width=400)

# draw arcs
coord = 50, 50, 250, 250
arc = myCanvas.create_arc(coord, start=0, extent=300, fill="purple")
arv2 = myCanvas.create_arc(coord, start=150, extent=215, fill="white")

# add to window and show
myCanvas.pack()
root.mainloop()
